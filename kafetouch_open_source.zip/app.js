document.addEventListener("DOMContentLoaded", () => {
    console.log("KafeTouch system initialized for Your Café");
});
