# KafeTouch

**KafeTouch** ist ein selbstbedienungsfähiges Bestellsystem für Cafés und Bäckereien – entwickelt von [Dein Name].

Dieses System wurde entwickelt zur Verbesserung des Workflows und der Kundenerfahrung an Theken.

## Lizenz & Nutzung

**Nicht-kommerzielle Nutzung ist kostenlos.**

Für **kommerzielle Nutzung (z.B. in Cafés, Franchise-Filialen, Gewerbe)** ist eine kostenpflichtige Lizenz erforderlich.

**Kontakt:** [deine E-Mail oder Gumroad-Seite]

© 2024 by [Dein Name]
